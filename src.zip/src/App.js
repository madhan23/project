import React, { Component } from "react";
import "./App.css";
import {Route,Switch,Redirect} from "react-router-dom";
import Home from "./components/home";
import NotFound from "./components/navigate/notfound";
import Rentals from "./components/navigate/rentals";
import Customer from './components/navigate/customer';
import Navigate from './components/navigate/navigation';
import AddMovie from "./components/Addmovie";
import Register from "./Register";
import Table from "./HTTP Request/data";
import Login from "./LoginForm";
class App extends Component {
  // componentDidMount(){
  //   document.body.style.background = "red";
  //  }
  render() {
    return (
  <React.Fragment>
        <Navigate/>
  <main className="container">
        <Switch>
        
        <Route path="/home" component={Home} />
        <Route path="/customer" component={Customer}/>
        <Route path="/rentals" component={Table}/>
        <Route path="/notfound" render={()=><NotFound />}/>
        <Route path="/login" component={Login}/>
        <Route path="/movies/:id"  component={AddMovie}/>
        <Route path="/register" component={Register}/>
        <Redirect from="/" exact  to="/home" />
        <Redirect to="/notfound"/>
      </Switch>
</main>
      </React.Fragment>
    );
  }
}

export default App