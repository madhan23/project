import React, { Component } from "react";
import { Input } from "../components/commons/Input";
import { Select } from "../components/commons/Select";
import { getGenres } from "./fakeGenreService";
import { getMovies } from "./fakeMovieService";
import Joi from "joi-browser";
import Form from "./commons/Form";
class MovieForm extends Form {
  state = {
    data: {
      _id: "",
      Title: "",
      Genre: "",
      NumberInStock: "",
      Rate: ""
    },
    genres: [],
    errors: {}
  };

  schema = {
    //  schema definition
    Title: Joi.string()
      .required()
      .label("Title")
      .regex(/[a-zA-Z]/),
    NumberInStock: Joi.number()
      .required()
      .min(1)
      .max(10),
    Rate: Joi.number()
      .required()
      .min(0)
      .max(5),
      
  };
  option = { abortEarly: false }; // validation purpose......

  componentDidMount() {
    console.log("movie add")
    const movieID = this.props.match.id;
    if (movieID === "new") return;
    const genres = getGenres();
    this.setState({ genres });

    const movie = getMovies(movieID);
    if (!movie) return this.props.history.replace("/notfound");
    this.setState({ data: this.movielist(movie) });
   
   
  
  }

  movielist(movie) {
    return {
      Title: movie.title,
      NumberInStock: movie.numberInStock,
      Rate: movie.dailyRentalRate,

    };
  }
  onSubmit=()=>{
    this.props.history.push('/home');

    }
  

  render() {
    const { errors, data,genres } = this.state;
    return (
      <div className="container mt-4">
        <form onSubmit={this.submitHandle}>
          <Input
            type="text"
            label="Title"
            change={this.changeHandle}
            value={data.Title || ""}
            error={errors.Title}
          />
          <Select 
          label="Genre" 
          data={genres}
          error={errors.Genre}
          />
          <Input
            type="Number"
            label="NumberInStock"
            change={this.changeHandle}
            value={data.NumberInStock || ""}
            error={errors.NumberInStock}
          />
          <Input
            type="Number"
            label="Rate"
            change={this.changeHandle}
            value={data.Rate || ""}
            error={errors.Rate}
          />
          <button
            type="submit"
            className="btn btn-primary z-depth-1 "
            disabled={this.errorhandle()}
          >
            Save
          </button>
        </form>
      </div>
    );
  }
}

export default MovieForm;
