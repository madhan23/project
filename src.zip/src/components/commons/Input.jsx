import React from 'react';
import "./Input.css";

const Input = ({label,value,type,change,error}) => {
const style={

boxShadow:'2px 2px 10px 0px #f5f5f5'
}
    return (
        <div>
        <label htmlFor={label}>{label}</label>
        <div className="form-group  row">
      
        <input  
        style={style}
        type={type} 
        name={label}
        value={value} 
        onChange={change} 
        className= "form-control col-4 ml-2" 
        id={label} 
        />
    {error && <span style={{color:"red"}}>{error}</span>}
        </div>
</div>
      );
}
 
export {Input};