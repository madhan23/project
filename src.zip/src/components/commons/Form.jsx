import React, { Component } from "react";
import Joi from "joi-browser";

class Form extends Component {
  state = {
    data: {},
    errors: {}
  };
  option = { abortEarly: false }; // validation purpose......

  errorhandle = () => {
    const { data } = this.state;
    const result = Joi.validate(data, this.schema, this.option);
    if (!result.error) return null;
    let errors = {};
    Object.entries(result.error.details).forEach(t => {
      errors[t[1].path] = t[1].message;
    });

    return errors;
  };
  validate = ({ name, value }) => {
    const field = { [name]: value };
    const schema = { [name]: this.schema[name] };
    const { error } = Joi.validate(field, schema);
    return error != null ? error.details[0].message : null;
  };

  changeHandle = ({ target }) => {
    let data = { ...this.state.data };
    const errors = { ...this.state.errors };
    let errmessage = this.validate(target);
    if (errmessage) errors[target.name] = errmessage;
    else delete errors[target.name];
    data[target.name] = target.value;
    this.setState({ data, errors });
  };

  submitHandle = e => {
    e.preventDefault();
    const { data } = this.state;
    const r = Joi.validate(data, this.schema, { abortEarly: true });
    let errors = this.errorhandle();

    this.setState({ errors: errors || {} });
    if (errors) return;
    this.props.history.push('/customer');
    this.onSubmit();
  };
}

export default Form;
