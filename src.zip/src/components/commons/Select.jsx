import React from 'react';
const Select=({label,data,error})=>
{
    return (
        <div>
        <label htmlFor={label}>{label}</label>
        <div className="form-group  row">
            <select  className="custom-select  col-4">
            
            {data.map(genre=><option key={genre.name} value={genre.name}>{genre.name}</option>)
            }
          </select> 
    {error && <span style={{color:"red"}}>{error}</span>}
        </div>
</div>
      );
}

export {Select}