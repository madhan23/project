import React from 'react';
const Main= () => {
    return (<h1>Main</h1>  );
}
 
export default Main;
