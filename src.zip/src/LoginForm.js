import React, { Component } from 'react';
import "./LoginForm.css";
import {Input} from "./components/commons/Input";
import Joi from 'joi-browser';
import Form from './components/commons/Form'
import {Link} from "react-router-dom";
class LoginForm extends Form {
    state={
         data:{ username:'', password:''},
         errors:{}
    }
schema={     //  schema definition
    username:Joi.string().required().min(3).label("Username"),
    password:Joi.string().required().alphanum().label("Password")
}
option={ abortEarly:false}  // validation purpose......
   

onSubmit=()=>{
console.log("submitted......")
}
componentDidMount(){
    console.log('DFJFJFJ')

   }


    render() { 
        const {data,errors}=this.state;
        return(
           
            <div   className="container mt-5 " >
            
            <form onSubmit={this.submitHandle}>
                <Input
                 type="text" 
                 label="username"
                 value={data.name} 
                 change={this.changeHandle}
                 error={errors.username}
                />
                <Input
        
                 type="password" 
                 label="password" 
                 value={data.name} 
                 change={this.changeHandle }
                 error={errors.password}
                />
              Don't have an account? <Link    className="stretched"to="/register">Sign up</Link><br/>
        <div>
           <button type="submit"  disabled={this.errorhandle()}className="btn btn-primary z-depth-1 ">Submit</button>
         </div>
            </form>
                </div>
              
        );
        
    }
}
 
export default LoginForm ;