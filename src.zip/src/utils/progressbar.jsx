import React from 'react';
import Bar from "../components/navigate/progressbar.gif"
const ProgressBar = () => {
    return (  
<div className="container">
        <div className="row">

        <div className="mx-auto w-50">
      <img className="img-fluid " src={Bar} alt="Logo" /> 
        </div>
    
        </div>
        </div>



    );
}
 
export default ProgressBar;