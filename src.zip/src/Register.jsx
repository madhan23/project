import React, { Component } from "react";
import Form from "./components/commons/Form";
import { Input } from "./components/commons/Input";
import Joi from "joi-browser";
class Register extends Form {
  state = {
    data: {
      Name: "",
      Password: "",
      EmailID: ""
    },
    errors: {}
  };

  schema = {
    //  schema definition
    Name: Joi.string().required(),
    EmailID: Joi.string()
      .required()
      .email(),
    Password: Joi.string().required()
  };
  option = { abortEarly: false }; // validation purpose......

  componentDidMount() {
    console.log("yesssss");
    this.props.history.push("/rentals");
  }
  onSubmit = () => {
    this.props.history.push("/login");
  };

  render() {
    const { data, errors } = this.state;
    return (
      <div className="container mt-5 ">
        <form onSubmit={this.submitHandle}>
          <Input
            type="text"
            label="Name"
            value={data.Name}
            change={this.changeHandle}
            error={errors.Name}
          />
          <Input
            type="text"
            label="EmailID"
            value={data.EmailID}
            change={this.changeHandle}
            error={errors.EmailID}
          />
          <Input
            type="password"
            label="Password"
            value={data.Password}
            change={this.changeHandle}
            error={errors.Password}
          />
          <div>
            <button
              type="submit"
              disabled={this.errorhandle()}
              className="btn btn-primary z-depth-1 "
            >
              Register
            </button>
          </div>
        </form>
      </div>
    );
  }
}

export default Register;
