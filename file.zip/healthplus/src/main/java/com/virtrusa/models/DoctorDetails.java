package com.virtrusa.models;

public class DoctorDetails {

}
