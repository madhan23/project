package com.virtrusa.models;

public class Booking {

}
