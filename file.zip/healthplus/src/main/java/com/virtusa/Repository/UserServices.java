package com.virtusa.Repository;

import org.springframework.data.repository.CrudRepository;

import com.virtrusa.models.User;

public interface UserServices extends CrudRepository<User,Integer>{
	 
}
