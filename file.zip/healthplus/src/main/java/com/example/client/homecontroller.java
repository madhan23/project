package com.example.client;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtrusa.models.User;
import com.virtusa.Repository.UserServices;

@Controller
public class homecontroller {
	@Autowired
	UserServices userservices;
public homecontroller () {	
	System.out.println("cjjfjfj");
}
@RequestMapping("/")
public String  Index(@ModelAttribute("user") User user) {
System.out.println("login");
	return "index.jsp";
}
@RequestMapping("/login")	
public String  login(@ModelAttribute("user") User user) {
System.out.println("mail"+user.getMailid());
System.out.println("password"+user.getPassword());
	return "booking.jsp";
}

@RequestMapping("/register")	
public String  Register(@ModelAttribute("user") User user) {
System.out.println("name"+user.getName());
System.out.println("age"+user.getAge());
System.out.println("mail"+user.getMailid());
System.out.println("password"+user.getPassword());
System.out.println("no"+user.getMobileno());
userservices.save(user);
	return "index.jsp";
}
}
